# magnificent-shaders
A Minecraft shaderpack that aims for realism, beauty, and performance. 

Requirements:

Minecraft

Optifine

A graphics card that supports OpenGL 4.2
